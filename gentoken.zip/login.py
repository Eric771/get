from CHRLINE import *
token = input('Token: ')
cl = CHRLINE(token, device="IOS")
print(token)